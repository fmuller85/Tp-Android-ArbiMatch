package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.arbimatch.class_metier.But;
import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;
import com.example.arbimatch.class_metier.ListeClub;
import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;
import com.example.arbimatch.sql.MatchDAO;

/**
 * Created by Flo on 04/12/13.
 */
public class AttribuerButActivity extends Activity{
    final Match m = ListeMatch.getMatchActuel();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attribuer_but);

        final String temps = this.getIntent().getStringExtra("Temps");

        Button bt_valider = (Button) findViewById(R.id.bt_valider);
        Button bt_retour = (Button) findViewById(R.id.bt_retour);
        final Spinner sp_club = (Spinner) findViewById(R.id.sp_club);
        final Spinner sp_joueur = (Spinner) findViewById(R.id.sp_joueur);


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(AttribuerButActivity.this, android.R.layout.simple_spinner_item, ListeMatch.lesClubDuMatch(m));

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_club.setAdapter(adapter);

        sp_club.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Club club = m.getLesClub().get(position);
                ArrayAdapter<String> listejoueur = new ArrayAdapter<String>(AttribuerButActivity.this, android.R.layout.simple_spinner_item, ListeClub.getLesTitu(club));
                listejoueur.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                sp_joueur.setAdapter(listejoueur);
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        /**** BOUTON VALIDER *****/
        bt_valider.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int positionJ = sp_joueur.getSelectedItemPosition();
                int positionC = sp_club.getSelectedItemPosition();

                MatchDAO mao = new MatchDAO(getApplicationContext());

                Joueur j = null;
                Club c = null;

                if(m.getClubdomicile().getId() == m.getLesClub().get(positionC).getId()){ // si club sélectionné = club domicile
                    j = m.getClubdomicile().getLesTitu().get(positionJ);
                    c = m.getClubdomicile();
                    But but = new But(c, j);
                    but.setTemps(temps);
                    m.ajouterButDomicile(but);
                    mao.createBut(m, but);
                    Toast.makeText(getApplicationContext(), "GOLAZOOO de "+j.getNom()+" "+j.getPrenom()+" à la "+temps+" min", Toast.LENGTH_SHORT).show();
                }else{ //sinon club exterieur
                    j = m.getClubexterieur().getLesTitu().get(positionJ);
                    c = m.getClubexterieur();
                    But but = new But(c, j);
                    but.setTemps(temps);
                    m.ajouterButExterieur(but);
                    mao.createBut(m, but);
                    Toast.makeText(getApplicationContext(), "GOLAZOOO de "+j.getNom()+" "+j.getPrenom()+" à la "+temps+" min", Toast.LENGTH_SHORT).show();
                }
                m.ajouterFilduMatch(temps + " : But pour "+c.getNom()+" de "+ j.getNom()+" "+j.getPrenom());
            }
        });

        bt_retour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                AttribuerButActivity.this.finish();
            }

        });
    }
}
