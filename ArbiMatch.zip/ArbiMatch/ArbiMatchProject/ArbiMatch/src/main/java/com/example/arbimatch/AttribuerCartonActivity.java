package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.arbimatch.class_metier.Carton;
import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;
import com.example.arbimatch.class_metier.ListeClub;
import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;
import com.example.arbimatch.sql.MatchDAO;

/**
 * Created by Flo on 04/12/13.
 */
public class AttribuerCartonActivity extends Activity {
    final Match m = ListeMatch.getMatchActuel();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.attribuer_carton);

        final String temps = this.getIntent().getStringExtra("Temps");

        Button bt_jaune = (Button) findViewById(R.id.bt_cartonJaune);
        Button bt_rouge = (Button) findViewById(R.id.bt_cartonRouge);
        Button bt_retour = (Button) findViewById(R.id.bt_retour);
        final RadioButton rb_club1 = (RadioButton) findViewById(R.id.rb_club1);
        final RadioButton rb_club2 = (RadioButton) findViewById(R.id.rb_club2);
        final RadioGroup rg_club = (RadioGroup) findViewById(R.id.rg_club);
        final Spinner sp_joueur = (Spinner) findViewById(R.id.sp_joueur);

        rb_club1.setText(m.getClubdomicile().getNom());
        rb_club2.setText(m.getClubexterieur().getNom());

        rb_club1.setId(0);
        rb_club2.setId(1);

       rb_club1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                afficheTitu(sp_joueur, m.getClubdomicile());
            }
        });

        rb_club2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                afficheTitu(sp_joueur, m.getClubexterieur());
            }
        });

        /**** BOUTON CARTON JAUNE *****/
        bt_jaune.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(rb_club1.isChecked() || rb_club2.isChecked()){
                    int positionJ = sp_joueur.getSelectedItemPosition();
                    Club c = null;
                    Joueur j = null;
                    if(rb_club1.isChecked()){ //si Club domicile sélectionné
                        c = m.getClubdomicile();
                        j = c.getLesTitu().get(positionJ);
                    }
                    if(rb_club2.isChecked()){ //si Club exterieur sélectionné
                        c = m.getClubexterieur();
                        j = c.getLesTitu().get(positionJ);
                    }
                    Boolean aDejaUnJaune = ajouterCartonJaune(c, j, temps);
                    afficheTitu(sp_joueur, c);
                    if(aDejaUnJaune){ // si le joueur a un 2ème carton jaune
                        Toast.makeText(getApplicationContext(), "Deuxième jaune c'est un rouge ! pour "+j.getNom() + " "+ j.getPrenom(), Toast.LENGTH_SHORT).show();
                        m.ajouterFilduMatch(temps + " : Carton un 2ème jaune pour "+ j.getNom()+" "+j.getPrenom()+" et donc c'est le rouge !");
                    }else{
                        Toast.makeText(getApplicationContext(), "Carton jaune pour "+j.getNom() + " "+ j.getPrenom(), Toast.LENGTH_SHORT).show();
                        m.ajouterFilduMatch(temps + " : C'est un carton jaune pour "+ j.getNom()+" "+j.getPrenom());
                    }
                }else{
                    Toast.makeText(getApplicationContext(), "Aucun club selectionnée", Toast.LENGTH_SHORT).show();
                }

            }
        });

        bt_rouge.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(rb_club1.isChecked() || rb_club2.isChecked()){
                    int positionJ = sp_joueur.getSelectedItemPosition();
                    Club c = null;
                    Joueur j = null;
                    if(rb_club1.isChecked()){ //si Club domicile sélectionné
                        c = m.getClubdomicile();
                        j = c.getLesTitu().get(positionJ);
                    }
                    if(rb_club2.isChecked()){ //si Club exterieur sélectionné
                        c = m.getClubexterieur();
                        j = c.getLesTitu().get(positionJ);
                    }
                    ajouterCartonRouge(c, j, temps);
                    afficheTitu(sp_joueur, c);
                    Toast.makeText(getApplicationContext(), "Carton rouge pour "+j.getNom() + " "+ j.getPrenom(), Toast.LENGTH_SHORT).show();
                    m.ajouterFilduMatch(temps + " : Carton rouge pour "+ j.getNom()+" "+j.getPrenom()+" Ohh le malheureux :(");
                }else{
                    Toast.makeText(getApplicationContext(), "Aucun club selectionnée", Toast.LENGTH_SHORT).show();
                }
            }
        });

        bt_retour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                AttribuerCartonActivity.this.finish();
            }
        });
    }

    //Renvoi 0 si le joueur n'a pas de carton
    //Renvoi 1 si le joueur a déjà un carton
    public boolean ajouterCartonJaune(Club c, Joueur j, String temps){
        Carton carton = new Carton(c, j);
        carton.setTemps(temps);
        carton.setJaune(1);
        carton.setRouge(0);
        MatchDAO mao = new MatchDAO(getApplicationContext());
        boolean resu = false;
        if(this.m.aUnJaune(j)){ //appel la fonction qui verifie que le joueur à un jaune
            this.m.ajouterCarton(carton); //ajoute d'abord un carton jaune
            mao.createCarton(m, carton);
            this.ajouterCartonRouge(c, j, temps); // puis un carton rouge
            resu = true;
        }else{
            this.m.ajouterCarton(carton);
            mao.createCarton(m, carton);
        }
        return resu;
    }

    public void ajouterCartonRouge(Club c, Joueur j, String temps){
        Carton carton = new Carton(c, j);
        MatchDAO mao = new MatchDAO(getApplicationContext());
        carton.setTemps(temps);
        carton.setJaune(0);
        carton.setRouge(1);
        mao.createCarton(m, carton);
        this.m.ajouterCarton(carton);
        this.m.exclureJoueur(j);
        c.getLesTitu().remove(j);
    }

    public void afficheTitu(Spinner sp_joueur, Club c){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(AttribuerCartonActivity.this, android.R.layout.simple_spinner_item, ListeClub.getLesTitu(c));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_joueur.setAdapter(adapter);
    }
}
