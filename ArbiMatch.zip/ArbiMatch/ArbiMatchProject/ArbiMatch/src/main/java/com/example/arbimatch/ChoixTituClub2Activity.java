package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.ListeClub;
import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;

/**
 * Created by Flo on 04/12/13.
 */
public class ChoixTituClub2Activity extends Activity{
    Match m = ListeMatch.getMatchActuel();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choix_titulaire_club);

        final Club c2 = m.getClubexterieur(); // recupere l'objet Club du club exterieur

        TextView txt_club = (TextView) findViewById(R.id.txt_club);
        Button bt_add = (Button) findViewById(R.id.bt_add);
        Button bt_del = (Button) findViewById(R.id.bt_del);
        Button bt_valider = (Button) findViewById(R.id.bt_valider);
        Button bt_retour = (Button) findViewById(R.id.bt_retour);

        final ListView lv_joueur = (ListView)findViewById(R.id.lv_joueur);
        final ListView lv_titu = (ListView)findViewById(R.id.lv_titu);

        updateListJoueur(c2 , lv_joueur, lv_titu);

        txt_club.setText(c2.getNom());
        lv_joueur.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);
        lv_titu.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE);


        // ------- BOUTON AJOUTER TITULAIRE ---------
        bt_add.setOnClickListener(new View.OnClickListener(){ //ajouter titulaire
            public void onClick(View v){
                int cntChoice = lv_joueur.getCount(); //récupere le nombre de joueurs dans la liste

                SparseBooleanArray sparseBooleanArray = lv_joueur.getCheckedItemPositions(); //récupère une liste de boolean, coché = true

                for(int i = 0; i < cntChoice; i++){// Pour tous les joueurs contenus dans la liste
                    if(sparseBooleanArray.get(i) == true){// Si joueur coché
                        c2.ajouterTitu(c2.getLesJoueurs().get(i));
                    }
                }
                for(int i = 0; i < c2.getLesTitu().size(); i++){
                    c2.getLesJoueurs().remove(c2.getLesTitu().get(i));
                }
                updateListJoueur(c2, lv_joueur, lv_titu);
            }});


        // ------ BOUTON SUPPRIMER TITULAIRE -----------
        bt_del.setOnClickListener(new View.OnClickListener(){ //retirer titulaire
            public void onClick(View v){
                int cntChoice = lv_titu.getCount();

                SparseBooleanArray sparseBooleanArray = lv_titu.getCheckedItemPositions();

                for(int i = 0; i < cntChoice; i++){// Pour tous les joueurs contenus dans la liste
                    if(sparseBooleanArray.get(i) == true){// Si joueur coché
                        c2.ajouterJoueur(c2.getLesTitu().get(i));
                    }
                }
                for(int i = 0; i < c2.getLesJoueurs().size(); i++){
                    c2.getLesTitu().remove(c2.getLesJoueurs().get(i));
                }
                updateListTitu(c2, lv_titu, lv_joueur);
            }

        });

        // ------- BOUTON VALIDER ----------
        bt_valider.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(ListeClub.verifTitu(c2) == true){
                    Intent i = new Intent(getBaseContext(), ModeMatchActivity.class);
                    startActivity(i);
                }else{
                    Toast.makeText(getApplicationContext(), "5 titulaire requis", Toast.LENGTH_SHORT).show();
                }
            }

        });

        // ------- BOUTON RETOUR -----------
        bt_retour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                ChoixTituClub2Activity.this.finish();
            }

        });
    }

    public void updateListJoueur(Club c, ListView lv_joueur, ListView lv_titu){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, ListeClub.getLesJoueurs(c));
        lv_joueur.setAdapter(adapter);

        if(c.getLesTitu().size() > 0){
            ArrayAdapter<String> titu = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, ListeClub.getLesTitu(c));
            lv_titu.setAdapter(titu);
        }
    }

    public void updateListTitu(Club c, ListView lv_titu, ListView lv_joueur){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, ListeClub.getLesJoueurs(c));
        lv_joueur.setAdapter(adapter);

        ArrayAdapter<String> titu = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, ListeClub.getLesTitu(c));
        lv_titu.setAdapter(titu);
    }
}
