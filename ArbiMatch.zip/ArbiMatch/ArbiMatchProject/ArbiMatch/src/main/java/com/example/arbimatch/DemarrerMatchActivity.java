package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;
import com.example.arbimatch.class_metier.ListeClub;
import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;
import com.example.arbimatch.sql.ClubDAO;
import com.example.arbimatch.sql.JoueurDAO;
import com.example.arbimatch.sql.MatchDAO;

import java.util.ArrayList;

/**
 * Created by Flo on 04/12/13.
 */
public class DemarrerMatchActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choix_clubs);

        final Spinner sp_clubdomicile = (Spinner) findViewById(R.id.sp_club1);
        final Spinner sp_clubexterieur = (Spinner) findViewById(R.id.sp_club2);

        ClubDAO cao = new ClubDAO(getApplicationContext());
        final ArrayList<Club> lesclubs = cao.getClub();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ListeClub.versTableau(lesclubs));

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_clubdomicile.setAdapter(adapter);
        sp_clubexterieur.setAdapter(adapter);

        Button bt_valider = (Button) findViewById(R.id.bt_valider);

        bt_valider.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int posclub1 = sp_clubdomicile.getSelectedItemPosition();
                int posclub2 = sp_clubexterieur.getSelectedItemPosition();

                Club clubdom = lesclubs.get(posclub1); // récupère un objet Club a partir de la liste déroulante "club domicile"
                Club clubext = lesclubs.get(posclub2);  // récupère un objet Club a partir de la liste déroulante "club exterieur"

                ajouteJoueurClub(clubdom);
                ajouteJoueurClub(clubext);

                MatchDAO mao = new MatchDAO(getApplicationContext());
                Match m = new Match(clubdom, clubext);

                mao.createMatch(m); // créer un match
                m.setId(mao.getMaxIdMatch()); //id correspond a l'id (autoincrement) de la table match du dernier match créer

                ListeMatch.ajouterMatch(m);

                Intent i = new Intent(getBaseContext(), ChoixTitulaireActivity.class);
                startActivityForResult(i, 2);
            }
        });

        Button bt_retour = (Button) findViewById(R.id.bt_retour);

        bt_retour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                DemarrerMatchActivity.this.finish();
            }

        });
    }

    public void ajouteJoueurClub(Club c){
        JoueurDAO jdao = new JoueurDAO(getApplicationContext());
        ArrayList<Joueur> lesJ = jdao.getJoueursduClub(c.getId());
        c.setLesJoueurs(lesJ);
    }
}
