package com.example.arbimatch;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.example.arbimatch.class_metier.But;
import com.example.arbimatch.class_metier.Carton;
import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;
import com.example.arbimatch.sql.MatchDAO;

import java.util.ArrayList;

/**
 * Created by Flo on 12/12/13.
 */
public class FicheMatchActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fiche_match);

        MatchDAO mao = new MatchDAO(getApplicationContext());
        ArrayList<Match> lesMatchs = mao.getInfoMatchs();

        int posMatch = this.getIntent().getIntExtra("positionMatch", -1);
        final Match m = lesMatchs.get(posMatch);

        m.setCarton(mao.getLesCarton(m.getId()));

        final String[] tabRemplacement = mao.getLesRemplacement(m.getId());


        TextView txt_club1 = (TextView) findViewById(R.id.txt_club1);
        TextView txt_but1 = (TextView) findViewById(R.id.txt_butc1);
        TextView txt_but2 = (TextView) findViewById(R.id.txt_butc2);
        TextView txt_club2 = (TextView) findViewById(R.id.txt_club2);
        TextView txt_date = (TextView) findViewById(R.id.txt_date);

        txt_club1.setText(m.getClubdomicile().getNom());
        txt_club2.setText(m.getClubexterieur().getNom());
        txt_but1.setText(""+m.getNbButDomicile());
        txt_but2.setText(""+m.getNbButExterieur());
        txt_date.setText(m.getDatematch());

        RadioButton rb_but = (RadioButton) findViewById(R.id.rb_but);
        RadioButton rb_carton = (RadioButton) findViewById(R.id.rb_carton);
        RadioButton rb_remp = (RadioButton) findViewById(R.id.rb_remp);



        rb_but.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Création de l'adapter
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(FicheMatchActivity.this, android.R.layout.simple_list_item_1, adapterBut(m.getButdomicile(), m.getButexterieur()));

                ListView listRemplacement = (ListView) findViewById(R.id.lv_remplacement);

                //On passe nos données au composant ListView
                listRemplacement.setAdapter(adapter);
            }
        });

        rb_carton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Création de l'adapter
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(FicheMatchActivity.this, android.R.layout.simple_list_item_1, adapterCarton(m.getCarton()));

                ListView listRemplacement = (ListView) findViewById(R.id.lv_remplacement);

                //On passe nos données au composant ListView
                listRemplacement.setAdapter(adapter);
            }
        });

        rb_remp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Création de l'adapter
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(FicheMatchActivity.this, android.R.layout.simple_list_item_1, tabRemplacement);

                ListView listRemplacement = (ListView) findViewById(R.id.lv_remplacement);

                //On passe nos données au composant ListView
                listRemplacement.setAdapter(adapter);
            }
        });

    }

    public String[] adapterCarton(ArrayList<Carton> lescarton){
        String[] resu = new String[lescarton.size()];
        int i = 0;
        for(Carton c : lescarton){
            if(c.getJaune() == 1){
                resu[i] = c.getTemps() + " Jaune : " + c.getJoueur().getNom() + " " + c.getJoueur().getPrenom();
            }else{
                resu[i] = c.getTemps() + "  Rouge : " + c.getJoueur().getNom() + " " + c.getJoueur().getPrenom();
            }
            i++;
        }
        return resu;
    }

    public String[] adapterBut(ArrayList<But> butext, ArrayList<But> butdom){
        String[] resu = new String[butdom.size() + butext.size()];
        int i = 0;
        int finTabResu = 0;

        for(But b : butdom){
            resu[i] = b.getTemps() + " " + b.getClub().getNom() + " " + b.getJoueur().getPrenom();
            i++;
            finTabResu = i;
        }

        for(But b : butext){
            resu[finTabResu] = b.getTemps() + " " + b.getClub().getNom() + " " + b.getJoueur().getPrenom();
            finTabResu++;
        }
        return resu;
    }

}
