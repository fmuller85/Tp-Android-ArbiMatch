package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;
import com.example.arbimatch.sql.MatchDAO;

import java.util.ArrayList;

/**
 * Created by Flo on 04/12/13.
 */
public class HistoriqueMatchActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.liste_match);

        ListView listeMatch = (ListView)findViewById(R.id.lv_match);
        MatchDAO mao = new MatchDAO(getApplicationContext());
        ArrayList<Match> lesMatchs = mao.getInfoMatchs();

        //Création de l'adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ListeMatch.versMatch(lesMatchs));

        //On passe nos données au composant ListView
        listeMatch.setAdapter(adapter);

        listeMatch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getBaseContext() , FicheMatchActivity.class);
                intent.putExtra("positionMatch", position);

                startActivityForResult(intent, 1);
            }
        });

        Button retour = (Button) findViewById(R.id.bt_retour);

        retour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                HistoriqueMatchActivity.this.finish();
            }

        });
    }
}
