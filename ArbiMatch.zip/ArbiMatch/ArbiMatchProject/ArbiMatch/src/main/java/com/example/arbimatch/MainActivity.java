package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;
import com.example.arbimatch.class_metier.ListeClub;
import com.example.arbimatch.sql.ClubDAO;
import com.example.arbimatch.sql.JoueurDAO;

/**
 * Created by Flo on 04/12/13.
 */

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ListeClub.jeuEssai();
        this.insertClubBase();
        this.insertJoueurBase();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.accueil_user);

        Button bt_demarrerMatch = (Button) findViewById(R.id.bt_demarrerMatch);

        bt_demarrerMatch.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                //méthode qui démarre une nouvelle Activity
                Intent i = new Intent(MainActivity.this, DemarrerMatchActivity.class);
                startActivity(i);
            }

        });

        Button bt_voirHistorique = (Button) findViewById(R.id.bt_consulterMatch);

        bt_voirHistorique.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, HistoriqueMatchActivity.class);
                startActivity(i);
            }
        });
    }

    public void insertClubBase(){
        ClubDAO cdao = new ClubDAO(getApplicationContext());
        for(Club c : ListeClub.getLesClubs()){
            cdao.createClub(c);
        }
    }

    public void insertJoueurBase(){
        JoueurDAO jdao = new JoueurDAO(getApplicationContext());
        for(Joueur j : ListeClub.getLesJoueurs()){
            jdao.createJoueur(j);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.action_settings:
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
