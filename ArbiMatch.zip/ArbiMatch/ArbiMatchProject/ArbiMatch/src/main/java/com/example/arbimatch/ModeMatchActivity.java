package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;

/**
 * Created by Flo on 04/12/13.
 */

public class ModeMatchActivity extends Activity implements Chronometer.OnChronometerTickListener {
    final Match m = ListeMatch.getMatchActuel();

    private boolean premiereMiTemps;

    public boolean isFinPremiereMiTemps() {
        return premiereMiTemps;
    }

    public void setPremiereMiTemps(boolean premiereMiTemps) {
        this.premiereMiTemps = premiereMiTemps;
    }

    public ModeMatchActivity() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mode_match);

        TextView clubdom = (TextView) findViewById(R.id.txt_club1);
        TextView clubext = (TextView) findViewById(R.id.txt_club2);

        clubdom.setText(m.getClubdomicile().getNom());
        clubext.setText(m.getClubexterieur().getNom());

        final ModeMatchActivity mma = new ModeMatchActivity();

        updateFilMatch();
        updateNbBut();
        disableButton();

        /******* START 1ere MI TEMPS ***************/
        Button startChrono = (Button) findViewById(R.id.bt_start_1ere);
        startChrono.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Toast.makeText(getApplicationContext(), "Début mi-temps", Toast.LENGTH_SHORT).show();
                ModeMatchActivity.this.startChronometer(null);

                Button startChrono = (Button) findViewById(R.id.bt_start_1ere);
                startChrono.setEnabled(false); //Desactive le bouton 1ere mi temps

                mma.setPremiereMiTemps(true);
            }
        });

        /******* START 2eme MI TEMPS **************/
        Button button2nd = (Button) findViewById(R.id.bt_start_2nde);
        button2nd.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Toast.makeText(getApplicationContext(), "Début 2nd mi-temps", Toast.LENGTH_SHORT).show();
                ModeMatchActivity.this.startChronometer2nd(null);

                Button button2nd = (Button) findViewById(R.id.bt_start_2nde);
                button2nd.setEnabled(false); //Désactive le bouton 2nde mi temps

                mma.setPremiereMiTemps(false);
            }
        });

        /****** ATTRIBUER BUT ******************/
        Button but = (Button) findViewById(R.id.bt_but);
        but.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
                Intent i = new Intent(getApplicationContext(), AttribuerButActivity.class);
                i.putExtra("Temps", chrono.getText());
                startActivityForResult(i, 1);
            }
        });

        /******* Stop chrono **************/
        Button bt_stop = (Button) findViewById(R.id.bt_pause);

        bt_stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                stopChronometer(null);
                disableButton();

                if(mma.isFinPremiereMiTemps()==true){
                    Button button2nd = (Button) findViewById(R.id.bt_start_2nde);
                    button2nd.setEnabled(true);
                    Button startChrono = (Button) findViewById(R.id.bt_start_1ere);
                    startChrono.setEnabled(false);
                    Toast.makeText(getApplicationContext(), "Fin de la première mi-temps", Toast.LENGTH_SHORT).show();
                }else{
                    Button startChrono = (Button) findViewById(R.id.bt_start_1ere);
                    startChrono.setEnabled(false);
                    Toast.makeText(getApplicationContext(), "Fin du match", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /***** ATTRIBUER CARTON *******************/
        Button carton = (Button) findViewById(R.id.bt_carton);

        carton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
                Intent i = new Intent(getApplicationContext(), AttribuerCartonActivity.class);
                i.putExtra("Temps", chrono.getText());
                startActivityForResult(i, 2);
            }
        });


        /****** REMPLACEMENT ******************/
        Button remplacement = (Button) findViewById(R.id.bt_remplacement);
        remplacement.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
                Intent i = new Intent(getApplicationContext(), RemplacementActivity.class);
                i.putExtra("Temps", chrono.getText());
                startActivityForResult(i, 3);
            }
        });

        /****** ACCUEIL ******************/
        Button accueil = (Button) findViewById(R.id.bt_accueil);
        accueil.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    public void startChronometer(View view) {
        Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
        chrono.setBase(SystemClock.elapsedRealtime());
        chrono.setOnChronometerTickListener(this);
        ((Chronometer) findViewById(R.id.chronometer)).start();
        this.enableButton();
    }

    public void startChronometer2nd(View view) {
        Chronometer chrono = ((Chronometer) findViewById(R.id.chronometer));
        //chrono.setFormat("MM:SS");
        chrono.setBase(SystemClock.elapsedRealtime() - (2700 * 1000));
        chrono.setOnChronometerTickListener(this);
        //chrono.setOnChronometerTickListener(this);
        ((Chronometer) findViewById(R.id.chronometer)).start();
        this.enableButton();
    }

    public void stopChronometer(View view) {
        ((Chronometer) findViewById(R.id.chronometer)).stop();
    }

    @Override
    public void onChronometerTick(Chronometer chronometer) {
        long t = SystemClock.elapsedRealtime() - chronometer.getBase();
        int h   = (int)(t/3600000);
        int m = (int)(t - h*3600000)/60000;
        int s= (int)(t - h*3600000- m*60000)/1000 ;

        m = m + (h*60);
        String hh = h < 10 ? "0"+h: h+"";
        String mm = m < 10 ? "0"+m: m+"";
        String ss = s < 10 ? "0"+s: s+"";
        chronometer.setText(mm + ":" + ss);
    }

    public void disableButton(){
        Button remplacement = (Button) findViewById(R.id.bt_remplacement);
        Button carton = (Button) findViewById(R.id.bt_carton);
        Button but = (Button) findViewById(R.id.bt_but);
        Button button2nd = (Button) findViewById(R.id.bt_start_2nde);
        Button bt_stop = (Button) findViewById(R.id.bt_pause);

        remplacement.setEnabled(false);
        carton.setEnabled(false);
        but.setEnabled(false);
        button2nd.setEnabled(false);
        bt_stop.setEnabled(false);
    }

    public void enableButton(){
        Button remplacement = (Button) findViewById(R.id.bt_remplacement);
        Button carton = (Button) findViewById(R.id.bt_carton);
        Button but = (Button) findViewById(R.id.bt_but);
        Button bt_stop = (Button) findViewById(R.id.bt_pause);

        remplacement.setEnabled(true);
        carton.setEnabled(true);
        but.setEnabled(true);
        bt_stop.setEnabled(true);
    }

    protected void onActivityResult(int requestCode, int resultcode, Intent data){
        if(requestCode == 1){//activity but
            if(resultcode == RESULT_OK){
                this.updateNbBut();
                this.updateFilMatch();
            }
        }
        if(requestCode == 2){//activity carton
            if(resultcode == RESULT_OK){
                this.updateFilMatch();
            }
        }
        if(requestCode == 3){//activity remplacement
            if(resultcode == RESULT_OK){
                this.updateFilMatch();
            }
        }
    }

    protected void updateNbBut(){
        TextView butclub1 = (TextView) findViewById(R.id.txt_butc1);
        TextView butclub2 = (TextView) findViewById(R.id.txt_butc2);

        butclub1.setText(""+m.getNbButDomicile());
        butclub2.setText(""+m.getNbButExterieur());
    }

    protected void updateFilMatch(){
        //Création de l'adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ListeMatch.getFilMatch(this.m.getFildumatch()));

        ListView filmatch = (ListView) findViewById(R.id.lv_filmatch);

        //On passe nos données au composant ListView
        filmatch.setAdapter(adapter);
    }



}
