package com.example.arbimatch;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;
import com.example.arbimatch.class_metier.ListeClub;
import com.example.arbimatch.class_metier.ListeMatch;
import com.example.arbimatch.class_metier.Match;
import com.example.arbimatch.sql.MatchDAO;

/**
 * Created by Flo on 04/12/13.
 */
public class RemplacementActivity extends Activity {
    final Match m = ListeMatch.getMatchActuel();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remplacement_joueur);

        final String temps = this.getIntent().getStringExtra("Temps");

        Button bt_valider = (Button) findViewById(R.id.bt_valider);
        Button bt_retour = (Button) findViewById(R.id.bt_retour);
        final RadioButton rb_club1 = (RadioButton) findViewById(R.id.rb_club1);
        final RadioButton rb_club2 = (RadioButton) findViewById(R.id.rb_club2);
        final Spinner sp_titu = (Spinner) findViewById(R.id.sp_titu);
        final Spinner sp_remplacant = (Spinner) findViewById(R.id.sp_remplacant);

        rb_club1.setText(m.getClubdomicile().getNom());
        rb_club2.setText(m.getClubexterieur().getNom());

        rb_club1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                afficheTitu(sp_titu, m.getClubdomicile());
                afficheRemplacant(sp_remplacant, m.getClubdomicile());
            }
        });

        rb_club2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                afficheTitu(sp_titu, m.getClubexterieur());
                afficheRemplacant(sp_remplacant, m.getClubexterieur());
            }
        });

        /**** BOUTON VALIDER *****/
        bt_valider.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(rb_club1.isChecked() || rb_club2.isChecked()){
                    int posJoueurTitu = sp_titu.getSelectedItemPosition();
                    int posJoueurRemp = sp_remplacant.getSelectedItemPosition();
                    Club c = null;
                    Joueur titu = null;
                    Joueur remplacant = null;
                    MatchDAO mao = new MatchDAO(getApplicationContext());
                    if(rb_club1.isChecked()){ //si Club domicile sélectionné
                        c = m.getClubdomicile();
                        titu = c.getLesTitu().get(posJoueurTitu);
                        remplacant = c.getLesJoueurs().get(posJoueurRemp);
                    }
                    if(rb_club2.isChecked()){ //si Club exterieur sélectionné
                        c = m.getClubexterieur();
                        titu = c.getLesTitu().get(posJoueurTitu);
                        remplacant = c.getLesJoueurs().get(posJoueurRemp);
                    }

                    if(remplacant.getRemplacant() == false){
                        c.ajouterTitu(remplacant); //ajoute le remplacant dans la liste des titus
                        c.ajouterJoueur(titu); //ajoute le joueur dans la liste des joueurs (remplacant)
                        c.getLesTitu().remove(titu);
                        c.getLesJoueurs().remove(remplacant);
                        titu.setRemplacant(true);
                        mao.createRemplacement(m, titu, remplacant, temps);
                        Toast.makeText(getApplicationContext(), "Remplacement de "+titu.getNom() + " "+titu.getPrenom()+" par "+remplacant.getNom()+ " "+remplacant.getPrenom(), Toast.LENGTH_SHORT).show();
                        m.ajouterFilduMatch(temps + " : C'est un changement pour "+ c.getNom()+" ,"+titu.getPrenom()+" est remplacé par "+remplacant.getPrenom());
                    }else{
                        Toast.makeText(getApplicationContext(), "Le joueur a déjà été remplacé", Toast.LENGTH_SHORT).show();
                    }

                    afficheTitu(sp_titu, c);
                    afficheRemplacant(sp_remplacant, c);

                }else{
                    Toast.makeText(getApplicationContext(), "Aucun club selectionnée", Toast.LENGTH_SHORT).show();
                }

            }
        });

        bt_retour.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent returnIntent = new Intent();
                setResult(RESULT_OK, returnIntent);
                RemplacementActivity.this.finish();
            }
        });
    }


    public void afficheTitu(Spinner sp_joueur, Club c){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(RemplacementActivity.this, android.R.layout.simple_spinner_item, ListeClub.getLesTitu(c));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_joueur.setAdapter(adapter);
    }

    public void afficheRemplacant(Spinner sp_joueur, Club c){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(RemplacementActivity.this, android.R.layout.simple_spinner_item, ListeClub.getLesJoueurs(c));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_joueur.setAdapter(adapter);
    }
}
