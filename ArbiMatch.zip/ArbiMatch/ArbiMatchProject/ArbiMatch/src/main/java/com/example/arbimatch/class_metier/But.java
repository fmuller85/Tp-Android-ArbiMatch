package com.example.arbimatch.class_metier;

/**
 * Created by Flo on 04/12/13.
 */
public class But {
    private Club club;
    private Joueur joueur;
    private String temps;

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }

    public Joueur getJoueur() {
        return joueur;
    }

    public void setJoueur(Joueur joueur) {
        this.joueur = joueur;
    }

    public String getTemps() {
        return temps;
    }

    public void setTemps(String temps) {
        this.temps = temps;
    }

    public But(){
    }

    public But(Club club, Joueur joueur) {
        this.club = club;
        this.joueur = joueur;
    }
}
