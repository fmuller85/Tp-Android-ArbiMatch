package com.example.arbimatch.class_metier;

/**
 * Created by Flo on 04/12/13.
 */
public class Carton{
    private Club club;
    private Joueur joueur;
    private String temps;
    private int jaune;
    private int rouge;

    public Club getClub() {
        return club;
    }

    public void setClub(Club club) {
        this.club = club;
    }

    public Joueur getJoueur() {
        return joueur;
    }

    public void setJoueur(Joueur joueur) {
        this.joueur = joueur;
    }

    public String getTemps() {
        return temps;
    }

    public void setTemps(String temps) {
        this.temps = temps;
    }

    public int getJaune() {
        return jaune;
    }

    public void setJaune(int jaune) {
        this.jaune = jaune;
    }

    public int getRouge() {
        return rouge;
    }

    public void setRouge(int rouge) {
        this.rouge = rouge;
    }

    public Carton(){
    }

    public Carton(Club club, Joueur joueur) {
        this.club = club;
        this.joueur = joueur;
    }
}
