package com.example.arbimatch.class_metier;

import java.util.ArrayList;

/**
 * Created by Flo on 04/12/13.
 */

public class Club{
    //attributs
    private int id;
    private String nom;
    private String ville;
    private ArrayList<Joueur> lesJoueurs;
    private ArrayList<Joueur> lesTitu;

    //accesseurs
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public ArrayList<Joueur> getLesJoueurs() {
        return lesJoueurs;
    }

    public void setLesJoueurs(ArrayList<Joueur> lesJoueurs) {
        this.lesJoueurs = lesJoueurs;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public ArrayList<Joueur> getLesTitu() {
        return lesTitu;
    }

    public void setLesTitu(ArrayList<Joueur> lesTitu) {
        this.lesTitu = lesTitu;
    }

    //Constructeur

    public Club(){
        this.lesJoueurs = new ArrayList<Joueur>();
        this.lesTitu = new ArrayList<Joueur>();
    }

    public Club(int id, String nom, String ville) {
        this.id = id;
        this.nom = nom;
        this.ville = ville;
        this.lesJoueurs = new ArrayList<Joueur>();
        this.lesTitu = new ArrayList<Joueur>();
    }

    //Méthode
    public void ajouterJoueur(Joueur j){
        this.lesJoueurs.add(j);
    }

    public void ajouterTitu(Joueur j){
        this.lesTitu.add(j);
    }

    public String ligneTableau(){
        return this.nom;
    }
}
