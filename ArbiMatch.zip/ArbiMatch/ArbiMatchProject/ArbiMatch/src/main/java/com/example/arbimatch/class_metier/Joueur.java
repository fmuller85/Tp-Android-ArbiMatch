package com.example.arbimatch.class_metier;

/**
 * Created by Flo on 04/12/13.
 */

public class Joueur {
    //attributs
    private int id;
    private String nom;
    private String prenom;
    private String datenaiss;
    private Boolean remplacant;
    private int idClub;


    //Accesseurs
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDatenaiss() {
        return datenaiss;
    }

    public void setDatenaiss(String datenaiss) {
        this.datenaiss = datenaiss;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Boolean getRemplacant() {
        return remplacant;
    }

    public void setRemplacant(Boolean remplacant) {
        this.remplacant = remplacant;
    }

    public int getIdClub() {
        return idClub;
    }

    public void setIdClub(int idClub) {
        this.idClub = idClub;
    }

    //Constructeur

    public Joueur(){
        this.remplacant = false;
    }

    public Joueur(int id, String nom, String prenom, String datenaiss, int idClub) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.datenaiss = datenaiss;
        this.remplacant = false;
        this.idClub = idClub;
    }

    public String ligneTableau(){
        return this.nom + " " + this.prenom.charAt(0) + ".";
    }
}
