package com.example.arbimatch.class_metier;

import java.util.ArrayList;

/**
 * Created by Flo on 04/12/13.
 */
public class ListeClub {
    private static ArrayList<Club> lesClubs;
    private static ArrayList<Joueur> lesJoueurs;

    public static ArrayList<Club> getLesClubs() {
        return lesClubs;
    }

    public static void setLesClubs(ArrayList<Club> lesClubs) {
        ListeClub.lesClubs = lesClubs;
    }

    public static ArrayList<Joueur> getLesJoueurs() {
        return lesJoueurs;
    }

    public static void setLesJoueurs(ArrayList<Joueur> lesJoueurs) {
        ListeClub.lesJoueurs = lesJoueurs;
    }

    public static void jeuEssai(){
        Club c1 = new Club(0, "Real Madrid", "Madrid");
        Club c2 = new Club(1, "Fc Barcelone", "Barcelone");
        Club c3 = new Club(2, "PSG", "Paris");

        lesClubs = new ArrayList<Club>();
        lesJoueurs = new ArrayList<Joueur>();
        lesClubs.add(c1);
        lesClubs.add(c2);
        lesClubs.add(c3);

        //Joueur Real Madrid
        Joueur j1 = new Joueur(0, "Iker", "Casillas", "27/05/1994", 0);
        Joueur j12 = new Joueur(1, "Sergio", "Ramos", "27/05/1994", 0);
        Joueur j13 = new Joueur(2, "Samir", "Khedira", "27/05/1994", 0);
        Joueur j14 = new Joueur(3, "Fabio", "Coentrao", "27/05/1994", 0);
        Joueur j15 = new Joueur(4, "Xabi", "Alonso", "27/05/1994", 0);
        Joueur j16 = new Joueur(5, "Lucas", "Modric", "27/05/1994", 0);
        Joueur j17 = new Joueur(6, "Karim", "Benzema", "27/05/1994", 0);
        Joueur j18 = new Joueur(7, "Cristiano", "Ronaldo", "27/05/1994", 0);
        Joueur j19 = new Joueur(8, "Angel", "Di Maria", "27/05/1994", 0);
        Joueur j20 = new Joueur(9, "Ricardo", "Carvalho", "27/05/1994", 0);
        c1.ajouterJoueur(j1);
        c1.ajouterJoueur(j12);
        c1.ajouterJoueur(j13);
        c1.ajouterJoueur(j14);
        c1.ajouterJoueur(j15);
        c1.ajouterJoueur(j16);
        c1.ajouterJoueur(j17);
        c1.ajouterJoueur(j18);
        c1.ajouterJoueur(j19);
        c1.ajouterJoueur(j20);

        //Joueur Barcelone
        Joueur j2 = new Joueur(10, "Victor", "Valdes", "01/09/1994", 1);
        Joueur j3 = new Joueur(11, "Carles", "Puyol", "01/09/1994", 1);
        Joueur j4 = new Joueur(12, "Gerard", "Pique", "01/09/1994", 1);
        Joueur j11 = new Joueur(13, "Dani", "Alves", "01/09/1994", 1);
        Joueur j5 = new Joueur(14, "Sergio", "Busquet", "01/09/1994", 1);
        Joueur j6 = new Joueur(15, "Xavi", "Hernandez", "01/09/1994", 1);
        Joueur j7 = new Joueur(16, "Andres", "Iniesta", "01/09/1994", 1);
        Joueur j8 = new Joueur(17, "Da Silva", "Neymar", "01/09/1994", 1);
        Joueur j9 = new Joueur(18, "Rodriguez", "Pedro", "01/09/1994", 1);
        Joueur j10 = new Joueur(19, "Lionel", "Messi", "01/09/1994", 1);
        c2.ajouterJoueur(j2);
        c2.ajouterJoueur(j3);
        c2.ajouterJoueur(j4);
        c2.ajouterJoueur(j5);
        c2.ajouterJoueur(j6);
        c2.ajouterJoueur(j7);
        c2.ajouterJoueur(j8);
        c2.ajouterJoueur(j9);
        c2.ajouterJoueur(j10);
        c2.ajouterJoueur(j11);

        //Joueur Paris
        Joueur j21 = new Joueur(20, "Sirigu", "Jesaispas", "01/09/1994", 2);
        Joueur j22 = new Joueur(21, "Thiago", "Silva", "01/09/1994", 2);
        Joueur j23 = new Joueur(22, "Maxwell", "H", "01/09/1994", 2);
        Joueur j24 = new Joueur(23, "Marco", "Verratti", "01/09/1994", 2);
        Joueur j25 = new Joueur(24, "Thiago", "Motta", "01/09/1994", 2);
        Joueur j26 = new Joueur(25, "Zlatan", "Ibra", "01/09/1994", 2);
        Joueur j27 = new Joueur(26, "Cavani", "Edinson", "01/09/1994", 2);
        Joueur j28 = new Joueur(27, "Lucas", "Moura", "01/09/1994", 2);
        Joueur j29 = new Joueur(28, "Lavezzi", "Ezequiel", "01/09/1994", 2);
        Joueur j30 = new Joueur(29, "Matuidi", "Blaise", "01/09/1994", 2);
        c3.ajouterJoueur(j21);
        c3.ajouterJoueur(j22);
        c3.ajouterJoueur(j23);
        c3.ajouterJoueur(j24);
        c3.ajouterJoueur(j25);
        c3.ajouterJoueur(j26);
        c3.ajouterJoueur(j27);
        c3.ajouterJoueur(j28);
        c3.ajouterJoueur(j29);
        c3.ajouterJoueur(j30);

        ListeClub.lesJoueurs.add(j1);
        ListeClub.lesJoueurs.add(j2);
        ListeClub.lesJoueurs.add(j3);
        ListeClub.lesJoueurs.add(j4);
        ListeClub.lesJoueurs.add(j5);
        ListeClub.lesJoueurs.add(j6);
        ListeClub.lesJoueurs.add(j7);
        ListeClub.lesJoueurs.add(j8);
        ListeClub.lesJoueurs.add(j9);
        ListeClub.lesJoueurs.add(j10);
        ListeClub.lesJoueurs.add(j11);
        ListeClub.lesJoueurs.add(j12);
        ListeClub.lesJoueurs.add(j13);
        ListeClub.lesJoueurs.add(j14);
        ListeClub.lesJoueurs.add(j15);
        ListeClub.lesJoueurs.add(j16);
        ListeClub.lesJoueurs.add(j17);
        ListeClub.lesJoueurs.add(j18);
        ListeClub.lesJoueurs.add(j19);
        ListeClub.lesJoueurs.add(j20);
        ListeClub.lesJoueurs.add(j21);
        ListeClub.lesJoueurs.add(j22);
        ListeClub.lesJoueurs.add(j23);
        ListeClub.lesJoueurs.add(j24);
        ListeClub.lesJoueurs.add(j25);
        ListeClub.lesJoueurs.add(j26);
        ListeClub.lesJoueurs.add(j27);
        ListeClub.lesJoueurs.add(j28);
        ListeClub.lesJoueurs.add(j29);
        ListeClub.lesJoueurs.add(j30);
    }

    //Retourne les club
    //pour adapter au spinner, ListView
    public static String[] versTableau(ArrayList<Club> listeClub){
        String[] resu = new String[listeClub.size()];
        int i = 0;
        for(Club c : listeClub){
            resu[i] = c.ligneTableau();
            i++;
        }
        return resu;
    }

    public static ArrayList<Club> versClub(){
        return lesClubs;
    }

    //Retourne les joueur d'un club passé en paramètre sous forme de tableau
    //pour adapter au spinner, ListView
    public static String[] getLesJoueurs(Club c){
            String[] resu = new String[c.getLesJoueurs().size()];
            int i = 0;
            for(Joueur j : c.getLesJoueurs()){
                resu[i] = j.ligneTableau();
                i++;
            }
            return resu;
    }

    //Retourne les titu d'un club passé en paramètre sous forme de tableau
    //pour adapter au spinner, ListView
    public static String[] getLesTitu(Club c){
        String[] resu = new String[c.getLesTitu().size()];
        int i = 0;
        for(Joueur j : c.getLesTitu()){
            resu[i] = j.ligneTableau();
            i++;
        }
        return resu;
    }

    /*
        Fonction qui verifie le nombre de titu dans un club
        titu limité à 5
        appelé lors du choix des titulaires
    */
    public static boolean verifTitu(Club c){
        boolean resu = false;
        if(c.getLesTitu().size() == 5){
            resu = true;
        }
        return resu;
    }
}
