package com.example.arbimatch.class_metier;

import java.util.ArrayList;

/**
 * Created by Flo on 04/12/13.
 */

/*
    Classe crée pour récupérer le dernier match crée
    ou
    adapter les objets en récuperant leur attribut sous forme de tableau
    pour que ListView et Spinner puissent afficher le nom des clubs, matchs et le fil du match
*/
public class ListeMatch {
    //Array list de match
    private static ArrayList<Match> lesMatch = new ArrayList<Match>();

    //récupère le match en cours, je pars du principe que le match actuel est le dernier match ajouter
    //lesMatch.size -1 car lesMatch commence à 0, alors que size() commence à 1
    public static Match getMatchActuel(){
        return lesMatch.get(lesMatch.size()-1);
    }

    //Ajoute un objet match
    public static void ajouterMatch(Match m){
        lesMatch.add(m);
    }

    //Retourne un tableau String correspondant au nom des 2 clubs du match
    //La 1ere case = club domicile
    //2 eme case = club exterieur
    //Utiliser pour afficher les noms des club dans la liste déroulante
    public static String[] lesClubDuMatch(Match m){
        String[] resu = new String[2];
        resu[0] = m.getClubdomicile().ligneTableau();
        resu[1] = m.getClubexterieur().ligneTableau();
        return resu;
    }

    public static String[] versMatch(ArrayList<Match> listeMatch){
        String[] resu = new String[listeMatch.size()];
        int i = 0;
        for(Match m : listeMatch){
            resu[i] = m.afficheMatch();
            i++;
        }
        return resu;
    }

    public static String[] getFilMatch(ArrayList<String> filmatch){
        String[] resu = new String[filmatch.size()];

        for (int i = filmatch.size() - 1; i >=0  ; i--){
            resu[i] = filmatch.get(i);
        }
        return resu;
    }
}
