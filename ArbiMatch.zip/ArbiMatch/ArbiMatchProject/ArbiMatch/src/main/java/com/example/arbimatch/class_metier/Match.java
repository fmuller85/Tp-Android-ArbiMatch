package com.example.arbimatch.class_metier;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Flo on 04/12/13.
 */
public class Match{
    private int id;
    private Club clubdomicile;
    private Club clubexterieur;
    private ArrayList<Club> lesClub;
    private ArrayList<But> butdomicile;
    private ArrayList<But> butexterieur;
    private ArrayList<Carton> carton;
    private ArrayList<Joueur> exclu;
    private ArrayList<String> fildumatch;

    private String datematch;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Club getClubdomicile() {
        return clubdomicile;
    }

    public void setClubdomicile(Club clubdomicile) {
        this.clubdomicile = clubdomicile;
    }

    public Club getClubexterieur() {
        return clubexterieur;
    }

    public void setClubexterieur(Club clubexterieur) {
        this.clubexterieur = clubexterieur;
    }

    public ArrayList<Club> getLesClub() {
        return lesClub;
    }

    public void setLesClub(ArrayList<Club> lesClub) {
        this.lesClub = lesClub;
    }

    public ArrayList<But> getButdomicile() {
        return butdomicile;
    }

    public void setButdomicile(ArrayList<But> butdomicile) {
        this.butdomicile = butdomicile;
    }

    public ArrayList<But> getButexterieur() {
        return butexterieur;
    }

    public void setButexterieur(ArrayList<But> butexterieur) {
        this.butexterieur = butexterieur;
    }

    public String getDatematch() {
        return datematch;
    }

    public void setDatematch(String datematch) {
        this.datematch = datematch;
    }

    public ArrayList<Carton> getCarton() {
        return carton;
    }

    public void setCarton(ArrayList<Carton> carton) {
        this.carton = carton;
    }

    public ArrayList<String> getFildumatch() {
        return fildumatch;
    }

    public void setFildumatch(ArrayList<String> fildumatch) {
        this.fildumatch = fildumatch;
    }

    public Match(){
        this.lesClub = new ArrayList<Club>();
        this.butdomicile = new ArrayList<But>();
        this.butexterieur = new ArrayList<But>();
        this.carton = new ArrayList<Carton>();
        this.exclu = new ArrayList<Joueur>();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yy HH:mm");
        Date unedate = new Date();
        this.datematch = simpleDateFormat.format(unedate);
        this.fildumatch = new ArrayList<String>();
    }

    public Match(Club clubdomicile, Club clubexterieur) {
        this.clubdomicile = clubdomicile;
        this.clubexterieur = clubexterieur;
        this.lesClub = new ArrayList<Club>();
            this.lesClub.add(clubdomicile);
            this.lesClub.add(clubexterieur);
        this.butdomicile = new ArrayList<But>();
        this.butexterieur = new ArrayList<But>();
        this.carton = new ArrayList<Carton>();
        this.exclu = new ArrayList<Joueur>();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yy HH:mm");
        Date unedate = new Date();
        this.datematch = simpleDateFormat.format(unedate);
        this.fildumatch = new ArrayList<String>();
    }

    public void ajouterButDomicile(But unbut){
        this.butdomicile.add(unbut);
    }

    public void ajouterButExterieur(But unbut){
        this.butexterieur.add(unbut);
    }

    public void ajouterCarton(Carton uncarton){
        this.carton.add(uncarton);
    }

    public void exclureJoueur(Joueur unjoueur){
        this.exclu.add(unjoueur);
    }

    public void ajouterFilduMatch(String fil){
        this.fildumatch.add(fil);
    }

    public int getNbButDomicile(){
        if(this.butdomicile.size() > 0){
            return this.butdomicile.size();
        }else{
            return 0;
        }
    }

    public int getNbButExterieur(){
        if(this.butexterieur.size() > 0){
            return this.butexterieur.size();
        }else{
            return 0;
        }
    }

    /*
    Renvoi false si le joueur n'a pas de carton jaune
    Renvoi true si le joueur a déjà un carton jaune
     */
    public boolean aUnJaune(Joueur unjoueur){
        int i = 0;
        boolean trouve = false;
        if(this.carton.size() > 0){
            while(i < this.carton.size() && trouve == false){
                if(this.carton.get(i).getJoueur().equals(unjoueur)){
                    trouve = true;
                }else{
                    i++;
                }
            }
        }
        return trouve;
    }

    public String afficheMatch(){
        return this.clubdomicile.getNom() + " "+ this.getNbButDomicile() + " - "+ this.getNbButExterieur() +" " + this.getClubexterieur().getNom()+"\n\r "+this.getDatematch();
    }
}
