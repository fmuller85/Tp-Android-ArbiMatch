package com.example.arbimatch.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.arbimatch.class_metier.Club;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Flo on 04/12/13.
 */
public class ClubDAO {
    private SQLiteDatabase db;
    private MatchSQLiteHelper dbHelper;

    public ClubDAO(Context context){
        dbHelper = new MatchSQLiteHelper(context);
        db = dbHelper.getWritableDatabase();

    }

    //close the db
    public void close(){
        db.close();
    }

    public void createClub(Club c){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_id", c.getId());
        contentValues.put("_nom",c.getNom());
        contentValues.put("_ville", c.getVille());

        db.insert("club", null, contentValues);
    }

    public void deleteClub(int id){
        db.delete("club", "_id = "+id, null);
    }

    public ArrayList<Club> getClub(){
        ArrayList<Club> clubsList = new ArrayList<Club>();

        //Nom de la colonne
        String[] tableColumns = new String[] {"_id", "_nom", "_ville"};

        Cursor cursor = db.query("club", tableColumns, null, null, null, null, null, null);
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            Club c = new Club();
            c.setId(cursor.getInt(0));
            c.setNom(cursor.getString(1));
            c.setVille(cursor.getString(2));

            clubsList.add(c);
            cursor.moveToNext();
        }
        return clubsList;
    }

    public Club getClubById(int idclub){
        Cursor cursor = db.query("club", new String[]{"_id","_nom","_ville"}, "_id = "+idclub, null, null, null, null);
        Club c = new Club();
        if (cursor != null)
            cursor.moveToFirst();
        c.setId(cursor.getInt(0));
        c.setNom(cursor.getString(1));
        c.setVille(cursor.getString(2));
        return c;
    }

    /*public ArrayList<Joueur> getJoueurs(){
        ArrayList<Joueur> joueursList = new ArrayList();

        //Nom de la colonne
        String[] tableColumns = new String[] {"_id", "_nom", "_prenom", "_dateN"};

        Cursor cursor = db.query("joueurs", tableColumns, null, null, null, null, null, null);
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            Joueur j = new Joueur();
            j.setId(cursor.getInt(0));
            j.setNom(cursor.getString(0));
            j.setPrenom(cursor.getString(0));
            j.setDateN(cursor.getString(0));

            joueursList.add(j);
            cursor.moveToNext();
        }
        return joueursList;
    }*/
}
