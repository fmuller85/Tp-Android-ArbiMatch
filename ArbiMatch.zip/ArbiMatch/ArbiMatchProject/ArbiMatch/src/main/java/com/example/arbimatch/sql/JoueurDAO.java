package com.example.arbimatch.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Flo on 04/12/13.
 */
public class JoueurDAO {
    private SQLiteDatabase db;
    private MatchSQLiteHelper dbHelper;

    public JoueurDAO(Context context){
        dbHelper = new MatchSQLiteHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    //close the db
    public void close(){
        db.close();
    }

    public void createJoueur(Joueur j){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_id", j.getId());
        contentValues.put("_nom",j.getNom());
        contentValues.put("_prenom", j.getPrenom());
        contentValues.put("_datenaiss", j.getDatenaiss());
        contentValues.put("_idClub", j.getIdClub()
        );

        db.insert("joueur", null, contentValues);
    }

    public void deleteClub(int id){
        db.delete("joueur", "_id = "+id, null);
    }

    public ArrayList<Joueur> getJoueursduClub(int idclub){
        ArrayList<Joueur> joueursList = new ArrayList();

        //Nom de la colonne
        String[] tableColumns = new String[] {"_id", "_nom", "_prenom", "_datenaiss", "_idClub"};

        Cursor cursor = db.query("joueur", tableColumns, "_idClub = "+idclub, null, null, null, null, null);
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            Joueur j = new Joueur();
            j.setId(cursor.getInt(0));
            j.setNom(cursor.getString(1));
            j.setPrenom(cursor.getString(2));
            j.setDatenaiss(cursor.getString(3));
            j.setIdClub(cursor.getInt(4));

            joueursList.add(j);
            cursor.moveToNext();
        }
        return joueursList;
    }
}
