package com.example.arbimatch.sql;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.appcompat.R;

import com.example.arbimatch.class_metier.But;
import com.example.arbimatch.class_metier.Carton;
import com.example.arbimatch.class_metier.Club;
import com.example.arbimatch.class_metier.Joueur;
import com.example.arbimatch.class_metier.Match;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Flo on 04/12/13.
 */
public class MatchDAO {
    private SQLiteDatabase db;
    private MatchSQLiteHelper dbHelper;

    public MatchDAO(Context context){
        dbHelper = new MatchSQLiteHelper(context);
        db = dbHelper.getWritableDatabase();

    }

    //close the db
    public void close(){
        db.close();
    }

    /*
    Insert un match dans la table match
     */
    public void createMatch(Match m){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_idClubDomicile", m.getClubdomicile().getId());
        contentValues.put("_idClubExterieur", m.getClubexterieur().getId());
        contentValues.put("_date", m.getDatematch());

        db.insert("match", null, contentValues);
    }

    /*
    Supprime une ligne match depuis l'id
     */
    public void deleteMatch(int id){
        db.delete("match", "_id = "+id, null);
    }

    /*public int getIdMatch(int id){
        String select = "Select _id from match Where _id ='" + id +
                "')";
        Cursor cursor = db.query("match", new String[] { "_id"
                }, "_id" + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        int i = cursor.getInt(0);
        return i;
    }*/

    /*
    Retourne le dernier id de la table match
     */
    public int getMaxIdMatch(){
        Cursor cursor = db.query("match", new String[]{"_id"}, "_id = ( SELECT MAX(_id) from match)", null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();
        int i = cursor.getInt(0);
        return i;
    }

    /*
    Insert un but dans la table but
     */
    public void createBut(Match m, But but){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_idmatch", m.getId());
        contentValues.put("_idClub", but.getJoueur().getIdClub());
        contentValues.put("_idJoueur", but.getJoueur().getId());
        contentValues.put("_temps", but.getTemps());

        db.insert("but", null, contentValues);
    }

    /*
    Insert une ligne carton dans la table carton
     */
    public void createCarton(Match m, Carton carton){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_idmatch", m.getId());
        contentValues.put("_idJoueur", carton.getJoueur().getId());
        contentValues.put("_cartonJaune", carton.getJaune());
        contentValues.put("_cartonRouge", carton.getRouge());
        contentValues.put("_temps", carton.getTemps());

        db.insert("carton", null, contentValues);
    }

    /*
    Insert une ligne remplacement dans la table remplacement
     */

    public void createRemplacement(Match m, Joueur titu, Joueur remplacant, String temps){
        ContentValues contentValues = new ContentValues();
        contentValues.put("_idmatch", m.getId());
        contentValues.put("_idJoueur1", titu.getId());
        contentValues.put("_idJoueur2", remplacant.getId());
        contentValues.put("_temps", temps);

        db.insert("remplacement", null, contentValues);
    }


    /*
     Retourne une collection de Match
     */
    public ArrayList<Match> getInfoMatchs(){
        ArrayList<Match> matchList = new ArrayList();

        //Nom de la colonne
        String[] tableColumns = new String[] {"_id", "_idClubDomicile", "_idClubExterieur", "_date"};

        Cursor cursor = db.query("match", tableColumns, null, null, null, null, null, null);
        cursor.moveToFirst();

        while(!cursor.isAfterLast()){
            Match m = new Match();
            m.setId(cursor.getInt(0));
            m.setClubdomicile(this.getLeClub(cursor.getInt(1)));
            m.setClubexterieur(this.getLeClub(cursor.getInt(2)));
            m.setButdomicile(this.getLesBut(cursor.getInt(0), m.getClubdomicile().getId()));
            m.setButexterieur(this.getLesBut(cursor.getInt(0),m.getClubexterieur().getId()));
            m.setDatematch(cursor.getString(3));

            matchList.add(m);
            cursor.moveToNext();
        }
        return matchList;
    }

    /*
        Retourne un objet club depuis un id
     */
    public Club getLeClub(int idclub){
        Cursor leclub = db.query("club", new String[]{"_id","_nom","_ville"}, "_id = "+idclub, null, null, null, null);
        Club c = new Club();
        if (leclub != null)
            leclub.moveToFirst();
        c.setId(leclub.getInt(0));
        c.setNom(leclub.getString(1));
        c.setVille(leclub.getString(2));
        return c;
    }

    /*
    Retourne une collection de But d'un match pour un club
     */
    public ArrayList<But> getLesBut(int idmatch, int idclub){
        Cursor cursor = db.query("but", new String[]{"_id","_idmatch","_idClub","_idJoueur","_temps"}, "_idmatch = "+idmatch+" AND _idClub="+idclub, null, null, null, null);
        ArrayList<But> lesbuts = new ArrayList<But>();

        if (cursor != null)
            cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            But unbut = new But();
            unbut.setClub(getLeClub(cursor.getInt(2)));
            unbut.setJoueur(getLeJoueur(cursor.getInt(3)));
            unbut.setTemps(cursor.getString(4));

            lesbuts.add(unbut);
            cursor.moveToNext();
        }
        return lesbuts;
    }

    /*
    Retourne un objet Joueur depuis un id
     */
    public Joueur getLeJoueur(int id){
        //Nom de la colonne
        String[] tableColumns = new String[] {"_id", "_nom", "_prenom", "_datenaiss", "_idClub"};

        Cursor cursor = db.query("joueur", tableColumns, "_id = "+id, null, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Joueur j = new Joueur();
        j.setId(cursor.getInt(0));
        j.setNom(cursor.getString(1));
        j.setPrenom(cursor.getString(2));
        j.setDatenaiss(cursor.getString(3));
        j.setIdClub(cursor.getInt(4));

        return j;
    }

    public ArrayList<Carton> getLesCarton(int idmatch){
        Cursor cursor = db.query("carton", new String[]{"_id","_idmatch","_idJoueur","_cartonJaune","_cartonRouge","_temps"}, "_idmatch = "+idmatch, null, null, null, null);
        ArrayList<Carton> lesCartons = new ArrayList<Carton>();

        if (cursor != null)
            cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            Carton uncarton = new Carton();
            uncarton.setClub(this.getLeClub(this.getLeJoueur(cursor.getInt(2)).getIdClub()));
            uncarton.setJoueur(this.getLeJoueur(cursor.getInt(2)));
            uncarton.setJaune(cursor.getInt(3));
            uncarton.setRouge(cursor.getInt(4));
            uncarton.setTemps(cursor.getString(5));

            lesCartons.add(uncarton);
            cursor.moveToNext();
        }
        return lesCartons;
    }

    public String[] getLesRemplacement(int idmatch){
        Cursor mCount= db.rawQuery("select count(*) from remplacement where _idmatch = "+ idmatch, null);
        mCount.moveToFirst();
        int nbligne= mCount.getInt(0);
        mCount.close();

        String[] resu = new String[nbligne];
        Cursor cursor = db.query("remplacement", new String[]{"_id","_idmatch","_idJoueur1","_idJoueur2","_temps"}, "_idmatch = "+idmatch, null, null, null, null);

        int i = 0;
        if (cursor != null)
            cursor.moveToFirst();
        while(!cursor.isAfterLast()){
            Joueur j1 = getLeJoueur(cursor.getInt(2));
            Joueur j2 = getLeJoueur(cursor.getInt(3));
            String temps = cursor.getString(4);

            resu[i] = temps +" "+j1.getPrenom()+" remplacé par "+j2.getPrenom();
            i++;
            cursor.moveToNext();
        }
        return resu;
    }
}
