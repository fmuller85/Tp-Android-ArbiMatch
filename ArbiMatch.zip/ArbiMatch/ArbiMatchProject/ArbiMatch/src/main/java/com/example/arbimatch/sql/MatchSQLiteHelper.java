package com.example.arbimatch.sql;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Flo on 04/12/13.
 */
public class MatchSQLiteHelper extends SQLiteOpenHelper{
    static final int DB_VERSION = 1;
    static final String DB_NAME = "joueurs_db";

    public MatchSQLiteHelper(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        //Execute create table SQL
        db.execSQL("CREATE TABLE club (_id INTEGER PRIMARY KEY, _nom TEXT NOT NULL, _ville TEXT NOT NULL);");
        db.execSQL("CREATE TABLE joueur (_id INTEGER PRIMARY KEY, _nom TEXT NOT NULL, _prenom TEXT NOT NULL, _datenaiss TEXT NOT NULL, _idClub INTEGER NOT NULL, FOREIGN KEY(_idClub) REFERENCES club(_id));");
        db.execSQL("CREATE TABLE match (_id INTEGER PRIMARY KEY AUTOINCREMENT, _idClubDomicile INTEGER NOT NULL, _idClubExterieur INTEGER NOT NULL, _date TEXT NOT NULL);");
        db.execSQL("CREATE TABLE but (_id INTEGER PRIMARY KEY AUTOINCREMENT, _idmatch INTEGER NOT NULL, _idClub INTEGER NOT NULL, _idJoueur INTEGER NOT NULL, _temps DATE NOT NULL, FOREIGN KEY(_idmatch) REFERENCES match(_id));");
        db.execSQL("CREATE TABLE carton (_id INTEGER PRIMARY KEY AUTOINCREMENT, _idmatch INTEGER NOT NULL, _idJoueur INTEGER NOT NULL, _cartonJaune integer NOT NULL, _cartonRouge integer NOT NULL, _temps DATE NOT NULL, FOREIGN KEY(_idmatch) REFERENCES match(id));");
        db.execSQL("CREATE TABLE remplacement (_id INTEGER PRIMARY KEY AUTOINCREMENT, _idmatch INTEGER NOT NULL, _idJoueur1 INTEGER NOT NULL, _idJoueur2 INTEGER NOT NULL, _temps DATE NOT NULL, FOREIGN KEY(_idmatch) REFERENCES match(id));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer){
        //DROP TABLE
        db.execSQL("DROP TABLE IF EXISTS joueur");
        db.execSQL("DROP TABLE IF EXISTS club");
        db.execSQL("DROP TABLE IF EXISTS carton");
        db.execSQL("DROP TABLE IF EXISTS but");
        db.execSQL("DROP TABLE IF EXISTS match");
        db.execSQL("DROP TABLE IF EXISTS remplacement");
        //Recreate TABLE
        onCreate(db);
    }
}
